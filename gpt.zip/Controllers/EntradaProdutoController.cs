using AplicacaoBackEnd.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AplicacaoBackAula.Controllers
{
    // DEFINIDO ANOTAÇÕES PARA EF IDENTIFICAR QUE É UMA CONTROLLER
    [Route("api/[controller]")]
    [ApiController]
    public class EntradasProdutoController : ControllerBase
    {
        // DEFININDO UM ATRIBUTO GLOBAL DO TIPO BdAulaBackendContext
        private readonly BdAulaBackendContext _context;

        // CRIADO O MÉTODO CONSTRUTOR DA CLASSE
        public EntradasProdutoController(BdAulaBackendContext context)
        {
            _context = context;
        }

        // LISTAR TODAS AS ENTRADAS DE PRODUTOS
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EntradaProdutoRespostaDto>>> GetEntradasProduto()
        {
            var entradas = await _context.EntradaProdutos
                .OrderBy(e => e.IdentradaProduto)
                .Select(e => new EntradaProdutoRespostaDto(
                    e.IdentradaProduto,
                    e.Iditem,
                    e.DataEntradaProduto,
                    e.QuantidadeEntrada,
                    e.Unidade,
                    e.ValorUnitarioEntrada))
                .ToListAsync();

            return Ok(entradas);
        }

        // LISTAR APENAS UMA ENTRADA PELO IDENTIFICADOR
        [HttpGet("{id}")]
        public async Task<ActionResult<EntradaProdutoRespostaDto>> GetEntradaProduto(int id)
        {
            var entrada = await _context.EntradaProdutos
                .FirstOrDefaultAsync(e => e.IdentradaProduto == id);

            if (entrada == null)
            {
                return NotFound(new { mensagem = "ENTRADA DE PRODUTO NÃO LOCALIZADA!" });
            }

            return Ok(new EntradaProdutoRespostaDto(
                entrada.IdentradaProduto,
                entrada.Iditem,
                entrada.DataEntradaProduto,
                entrada.QuantidadeEntrada,
                entrada.Unidade,
                entrada.ValorUnitarioEntrada));
        }

        // INSERIR UMA ENTRADA E ATUALIZAR O ESTOQUE RELACIONADO
        [HttpPost]
        public async Task<ActionResult> PostEntradaProduto(EntradaProdutoCriarDto dados)
        {
            var produto = await _context.Produtos
                .FirstOrDefaultAsync(p => p.Iditem == dados.IdItem);

            if (produto == null)
            {
                return BadRequest(new { mensagem = "O PRODUTO INFORMADO NÃO FOI LOCALIZADO!" });
            }

            if (dados.Quantidade <= 0 || dados.ValorUnitario <= 0)
            {
                return BadRequest(new { mensagem = "QUANTIDADE E VALOR UNITÁRIO DEVEM SER MAIORES QUE ZERO!" });
            }

            await using var transaction = await _context.Database.BeginTransactionAsync();

            try
            {
                // BUSCAR OU CRIAR O REGISTRO DE ESTOQUE
                var estoque = await _context.Estoques
                    .FirstOrDefaultAsync(e => e.Iditem == dados.IdItem);

                if (estoque == null)
                {
                    estoque = new Estoque
                    {
                        Iditem = dados.IdItem,
                        QuantidadeEstoque = 0
                    };
                    _context.Estoques.Add(estoque);
                    await _context.SaveChangesAsync();
                }

                // DADOS DA TABELA ENTRADA_PRODUTO
                var entrada = new EntradaProduto
                {
                    Iditem = dados.IdItem,
                    DataEntradaProduto = dados.DataEntrada.Date,
                    QuantidadeEntrada = dados.Quantidade,
                    Unidade = dados.Unidade,
                    ValorUnitarioEntrada = dados.ValorUnitario
                };

                _context.EntradaProdutos.Add(entrada);

                // ATUALIZAR A QUANTIDADE DO ESTOQUE
                estoque.QuantidadeEstoque += dados.Quantidade;

                // ATUALIZAR O PREÇO DE VENDA CADASTRADO PARA O PRODUTO
                produto.PrecoVenda = dados.ValorUnitario;

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                return CreatedAtAction(
                    nameof(GetEntradaProduto),
                    new { id = entrada.IdentradaProduto },
                    new EntradaProdutoRespostaDto(
                        entrada.IdentradaProduto,
                        entrada.Iditem,
                        entrada.DataEntradaProduto,
                        entrada.QuantidadeEntrada,
                        entrada.Unidade,
                        entrada.ValorUnitarioEntrada));
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return StatusCode(500, new
                {
                    mensagem = "ERRO NO CADASTRO DA ENTRADA DE PRODUTO",
                    erro = ex.InnerException?.Message ?? ex.Message
                });
            }
        }

        // ALTERAR UMA ENTRADA E AJUSTAR A QUANTIDADE DO ESTOQUE
        [HttpPut("{id}")]
        public async Task<IActionResult> PutEntradaProduto(int id, EntradaProdutoCriarDto dados)
        {
            var entrada = await _context.EntradaProdutos
                .FirstOrDefaultAsync(e => e.IdentradaProduto == id);

            if (entrada == null)
            {
                return NotFound(new { mensagem = "ENTRADA DE PRODUTO NÃO LOCALIZADA!" });
            }

            // IDITEM FAZ PARTE DA CHAVE PRIMÁRIA COMPOSTA; NÃO ALTERAR O PRODUTO DA ENTRADA
            if (entrada.Iditem != dados.IdItem)
            {
                return BadRequest(new { mensagem = "NÃO É POSSÍVEL TROCAR O PRODUTO DE UMA ENTRADA EXISTENTE. EXCLUA E CADASTRE OUTRA ENTRADA." });
            }

            if (dados.Quantidade <= 0 || dados.ValorUnitario <= 0)
            {
                return BadRequest(new { mensagem = "QUANTIDADE E VALOR UNITÁRIO DEVEM SER MAIORES QUE ZERO!" });
            }

            var estoque = await _context.Estoques
                .FirstOrDefaultAsync(e => e.Iditem == entrada.Iditem);
            var produto = await _context.Produtos
                .FirstOrDefaultAsync(p => p.Iditem == entrada.Iditem);

            if (estoque == null || produto == null)
            {
                return Conflict(new { mensagem = "PRODUTO OU ESTOQUE RELACIONADO NÃO FOI LOCALIZADO!" });
            }

            await using var transaction = await _context.Database.BeginTransactionAsync();

            try
            {
                // SUBTRAIR A QUANTIDADE ANTIGA E SOMAR A NOVA
                int novaQuantidadeEstoque = estoque.QuantidadeEstoque
                    - entrada.QuantidadeEntrada + dados.Quantidade;

                if (novaQuantidadeEstoque < 0)
                {
                    return Conflict(new { mensagem = "A ALTERAÇÃO DEIXARIA O ESTOQUE NEGATIVO." });
                }

                estoque.QuantidadeEstoque = novaQuantidadeEstoque;
                entrada.DataEntradaProduto = dados.DataEntrada.Date;
                entrada.QuantidadeEntrada = dados.Quantidade;
                entrada.Unidade = dados.Unidade;
                entrada.ValorUnitarioEntrada = dados.ValorUnitario;
                produto.PrecoVenda = dados.ValorUnitario;

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();
                return NoContent();
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return StatusCode(500, new
                {
                    mensagem = "ERRO AO ALTERAR A ENTRADA DE PRODUTO",
                    erro = ex.InnerException?.Message ?? ex.Message
                });
            }
        }

        // EXCLUIR UMA ENTRADA E DIMINUIR A QUANTIDADE CORRESPONDENTE DO ESTOQUE
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEntradaProduto(int id)
        {
            var entrada = await _context.EntradaProdutos
                .FirstOrDefaultAsync(e => e.IdentradaProduto == id);

            if (entrada == null)
            {
                return NotFound(new { mensagem = "ENTRADA DE PRODUTO NÃO LOCALIZADA!" });
            }

            var estoque = await _context.Estoques
                .FirstOrDefaultAsync(e => e.Iditem == entrada.Iditem);

            if (estoque == null || estoque.QuantidadeEstoque < entrada.QuantidadeEntrada)
            {
                return Conflict(new { mensagem = "NÃO É POSSÍVEL EXCLUIR: A QUANTIDADE DO ESTOQUE ESTÁ INCONSISTENTE." });
            }

            await using var transaction = await _context.Database.BeginTransactionAsync();

            try
            {
                estoque.QuantidadeEstoque -= entrada.QuantidadeEntrada;
                _context.EntradaProdutos.Remove(entrada);
                await _context.SaveChangesAsync();
                await transaction.CommitAsync();
                return NoContent();
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return StatusCode(500, new
                {
                    mensagem = "ERRO AO EXCLUIR A ENTRADA DE PRODUTO",
                    erro = ex.InnerException?.Message ?? ex.Message
                });
            }
        }
    }
}
