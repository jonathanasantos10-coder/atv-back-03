﻿namespace AplicacaoBackAula.DTO
{
    public class EntradaProdutoDTO
    {
    }
}
